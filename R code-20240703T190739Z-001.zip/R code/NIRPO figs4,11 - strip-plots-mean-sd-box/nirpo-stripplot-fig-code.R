#HYBRID STRIP CHARTS WITH BOX - to summarize data by group

library(ggplot2)
library(ggpubr) #to group plots in one figure

#Other options not used:
library(EnvStats) #package to add sample size to graphs
library(gridExtra) #another package to group plots in one figure

#To put more than one graph on a page see:
  http://www.sthda.com/english/articles/24-ggpubr-publication-ready-plots/81-ggplot2-easy-way-to-mix-multiple-graphs-on-the-same-page/

## to save a fig use the code
tiff('filename.tiff', width = 4, height = 4, units = 'in', res = 300)
#plot code
dev.off() ## need this to finish saving
## will not get a preview  - you know it will work because you'll get "RStudioGD 2"     
  
###########################################################################
#FIGURE 5. Vegetation habitat types x soil moisture metrics

setwd("/Users/amy.akillik/Desktop/NIRPO veg analyses/R analyses/code")
nirpoveg_r <- read.csv("~/Desktop/NIRPO veg analyses/R analyses/nirpoveg_r.csv")
View(nirpoveg_r)

P1 <- ggplot(nirpoveg_r, 
             aes(x=veghab.4, y = volsoilmoist)
) +
  geom_boxplot(aes(color= veghab.4),show.legend=FALSE, outlier.shape = NA, coef = 0) +
  geom_jitter(
    aes(color = veghab.4, fill=veghab.4, alpha = 0.3), 
    position = position_jitterdodge(jitter.width = 0.5, dodge.width = 1),
    size = 3
  ) +
  stat_summary(
    aes(fill = "black"),
    fun.data="mean_sdl",  
    fun.args = list(mult=1), 
    geom = "pointrange",
    linewidth = 1,  
    size = 0.8,
    position = position_dodge(0.8)
  ) +
  scale_color_manual(
    values =  c("royalblue4", "salmon1", "#E69F00", "skyblue")
  )+
  scale_x_discrete(
    limits = c("dry tundra", "moist tundra", "wet tundra", "aquatic"), 
    name = "Site moisture groups") +
  scale_y_continuous(
    name = "Volumetric soil moisture (%)", 
    limits=c(0, 80)) +
  theme_bw() +
  theme(
    text=element_text(family="Arial"),
    legend.position = "none", 
    axis.text.x=element_text(face="bold", size=10), 
    axis.text.y=element_text(face="bold", size=10), 	
    axis.title.x=element_text(face="bold", size=12),
    axis.title.y=element_text(face="bold", size=12)
  )

#site moisture type (veghab_4) x scalar site moisture
P2 <- ggplot(nirpoveg_r, 
             aes(x=veghab.4, y = scalsitemoist)
)+
  geom_boxplot(aes(color= veghab.4),show.legend=FALSE, outlier.shape = NA, coef = 0) +
  geom_jitter(
    aes(color = veghab.4, fill=veghab.4, alpha = 0.3), 
    position = position_jitterdodge(jitter.width = 0.5, dodge.width = 1),
    size = 3
  ) +
  stat_summary(
    aes(fill = "black"),
    fun.data="mean_sdl",  
    fun.args = list(mult=1), 
    geom = "pointrange",  
    linewidth = 1, 
    size = 0.8,
    position = position_dodge(0.8)
  ) +
  scale_color_manual(
    values =  c("royalblue4", "salmon1", "#E69F00", "skyblue")
  )+
  scale_x_discrete(
    limits = c("dry tundra", "moist tundra", "wet tundra", "aquatic"), 
    name = "") +
  scale_y_continuous(
    name = "Site moisture (scalar)", 
    limits=c(0, 10.5),
    breaks = c(0, 2, 4, 6, 8, 10)) +
  theme_bw() +
  theme(
    text=element_text(family="Arial"),
    legend.position = "none", 
    axis.text.x=element_text(face="bold", size=10), 
    axis.text.y=element_text(face="bold", size=10), 	
    axis.title.x=element_text(face="bold", size=12),
    axis.title.y=element_text(face="bold", size=12)
  )

#vegetation habitat type (16) x volumetric soil moisture
P1a <- ggplot(nirpoveg_r, 
              aes(x=veghab.16, y = volsoilmoist)
)+
  geom_boxplot(aes(color= veghab.4),show.legend=FALSE, outlier.shape = NA, coef = 0) +
  
  geom_jitter(
    aes(color = veghab.4, fill=veghab.4, alpha = 0.3), 
    position = position_jitterdodge(jitter.width = 0.5, dodge.width = 1),
    size = 3
  ) +
  stat_summary(
    aes(fill = "black"),
    fun.data="mean_sdl",  
    fun.args = list(mult=1), 
    geom = "pointrange",
    linewidth = 1,   
    size = 0.6,
    position = position_dodge(0.8)
  ) +
  scale_color_manual(
    values =  c("royalblue4", "salmon1", "#E69F00", "skyblue")
  )+
  scale_x_discrete(
    limits = c("D1", "Dsn", "Dz", "M1", "Mz", "M3", "M3t", "L2", "W1", "W2", "A1", "A1t", "A2", "A3t", "A4t", "L3"), 
    name = "Vegetation habitat types", guide = guide_axis(angle=90)) +
  scale_y_continuous(
    name = "", 
    limits=c(0, 80)) +
  theme_bw() +
  theme(
    text=element_text(family="Arial"),
    legend.position = "none", 
    axis.text.x=element_text(face="bold", size=10), 
    axis.text.y=element_text(face="bold", size=10), 	
    axis.title.x=element_text(face="bold", size=12),
    axis.title.y=element_text(face="bold", size=12)
  )

##vegetation habitat type (16) x scalar site moisture
P2a <- ggplot(nirpoveg_r, 
              aes(x=veghab.16, y = scalsitemoist)
)+
  geom_boxplot(aes(color= veghab.4),show.legend=FALSE, outlier.shape = NA, coef = 0) +
  
  geom_jitter(
    aes(color = veghab.4, fill=veghab.4, alpha = 0.3), 
    position = position_jitterdodge(jitter.width = 0.5, dodge.width = 1),
    size = 3
  ) +
  stat_summary(
    aes(fill = "black"),
    fun.data="mean_sdl",  
    fun.args = list(mult=1), 
    geom = "pointrange",
    linewidth = 1,   
    size = 0.6,
    position = position_dodge(0.6)
  ) +
  scale_color_manual(
    values =  c("royalblue4", "salmon1", "#E69F00", "skyblue")
  )+
  scale_x_discrete(
    limits = c("D1", "Dsn", "Dz", "M1", "Mz", "M3", "M3t", "L2", "W1", "W2", "A1", "A1t", "A2", "A3t", "A4t", "L3"), 
    name = "", guide = guide_axis(angle=90)) +
  scale_y_continuous(
    name = "", 
    limits=c(0, 10.5),
    breaks = c(0, 2, 4, 6, 8, 10)) +
  theme_bw() +
  theme(
    text=element_text(family="Arial"),
    legend.position = "none", 
    axis.text.x=element_text(face="bold", size=10), 
    axis.text.y=element_text(face="bold", size=10), 	
    axis.title.x=element_text(face="bold", size=12),
    axis.title.y=element_text(face="bold", size=12)
  )

## to save
tiff('fig 4-plot-moisture-v8-Rplot.tiff', width = 9, height = 7, units = 'in', res = 300)
#align = "hv" aligns panels both horizontally and vertically
ggarrange(P2, P2a, P1, P1a, ncol = 2, nrow = 2, labels = c("a", "b", "c", "d"), 
          font.label=list(color="black",size=16, face="bold"), align = "hv")
dev.off() ## need this code to finish saving

###########################################################################
#FIGURE 11. Vegetation habitat types x LAI and NDVI

P3 <- ggplot(nirpoveg_r, 
             aes(x=veghab.4, y = lai)
) +
  geom_boxplot(aes(color= veghab.4),show.legend=FALSE, outlier.shape = NA, coef = 0) +
  geom_jitter(
    aes(color = veghab.4, fill=veghab.4, alpha = 0.3), 
    position = position_jitterdodge(jitter.width = 0.5, dodge.width = 1),
    size = 3
  ) +
  stat_summary(
    aes(fill = "black"),
    fun.data="mean_sdl",  
    fun.args = list(mult=1), 
    geom = "pointrange",
    linewidth = 1,  
    size = 0.8,
    position = position_dodge(0.8)
  ) +
  scale_color_manual(
    values =  c("royalblue4", "salmon1", "#E69F00", "skyblue")
  )+
  scale_x_discrete(
    limits = c("dry tundra", "moist tundra", "wet tundra", "aquatic"), 
    name = "Site moisture groups") +
  scale_y_continuous(
    name = "LAI", 
    limits=c()) +
  theme_bw() +
  theme(
    text=element_text(family="Arial"),
    legend.position = "none", 
    axis.text.x=element_text(face="bold", size=10), 
    axis.text.y=element_text(face="bold", size=10), 	
    axis.title.x=element_text(face="bold", size=12),
    axis.title.y=element_text(face="bold", size=12)
  )

#site moisture type (veghab_4) x NDVI
P4 <- ggplot(nirpoveg_r, 
             aes(x=veghab.4, y = ndvi.2)
)+
  geom_boxplot(aes(color= veghab.4),show.legend=FALSE, outlier.shape = NA, coef = 0) +
  geom_jitter(
    aes(color = veghab.4, fill=veghab.4, alpha = 0.3), 
    position = position_jitterdodge(jitter.width = 0.5, dodge.width = 1),
    size = 3
  ) +
  stat_summary(
    aes(fill = "black"),
    fun.data="mean_sdl",  
    fun.args = list(mult=1), 
    geom = "pointrange",  
    linewidth = 1, 
    size = 0.8,
    position = position_dodge(0.8)
  ) +
  scale_color_manual(
    values =  c("royalblue4", "salmon1", "#E69F00", "skyblue")
  )+
  scale_x_discrete(
    limits = c("dry tundra", "moist tundra", "wet tundra", "aquatic"), 
    name = "") +
  scale_y_continuous(
    name = "NDVI", 
    limits=c(0, 0.8)) +
  theme_bw() +
  theme(
    text=element_text(family="Arial"),
    legend.position = "none", 
    axis.text.x=element_text(face="bold", size=10), 
    axis.text.y=element_text(face="bold", size=10), 	
    axis.title.x=element_text(face="bold", size=12),
    axis.title.y=element_text(face="bold", size=12)
  )

#vegetation habitat type (16) x LAI
P3a <- ggplot(nirpoveg_r, 
              aes(x=veghab.16, y = lai)
)+
  geom_boxplot(aes(color= veghab.4),show.legend=FALSE, outlier.shape = NA, coef = 0) +
  geom_jitter(
    aes(color = veghab.4, fill=veghab.4, alpha = 0.3), 
    position = position_jitterdodge(jitter.width = 0.5, dodge.width = 1),
    size = 3
  ) +
  stat_summary(
    aes(fill = "black"),
    fun.data="mean_sdl",  
    fun.args = list(mult=1), 
    geom = "pointrange",
    linewidth = 1,   
    size = 0.6,
    position = position_dodge(0.8)
  ) +
  scale_color_manual(
    values =  c("royalblue4", "salmon1", "#E69F00", "skyblue")
  )+
  scale_x_discrete(
    limits = c("D1", "Dsn", "Dz", "M1", "Mz", "M3", "M3t", "L2", "W1", "W2", "A1", "A1t", "A2", "A3t", "A4t", "L3"), 
    name = "Vegetation habitat types", guide = guide_axis(angle=90)) +
  scale_y_continuous(
    name = "", 
    limits=c()) +
  theme_bw() +
  theme(
    text=element_text(family="Arial"),
    legend.position = "none", 
    axis.text.x=element_text(face="bold", size=10), 
    axis.text.y=element_text(face="bold", size=10), 	
    axis.title.x=element_text(face="bold", size=12),
    axis.title.y=element_text(face="bold", size=12)
  )

##vegetation habitat type (16) x NDVI
P4a <- ggplot(nirpoveg_r, 
              aes(x=veghab.16, y = ndvi.2)
)+
  geom_boxplot(aes(color= veghab.4),show.legend=FALSE, outlier.shape = NA, coef = 0) +
  
  geom_jitter(
    aes(color = veghab.4, fill=veghab.4, alpha = 0.3), 
    position = position_jitterdodge(jitter.width = 0.5, dodge.width = 1),
    size = 3
  ) +
  stat_summary(
    aes(fill = "black"),
    fun.data="mean_sdl",  
    fun.args = list(mult=1), 
    geom = "pointrange",
    linewidth = 1,   
    size = 0.6,
    position = position_dodge(0.6)
  ) +
  scale_color_manual(
    values =  c("royalblue4", "salmon1", "#E69F00", "skyblue")
  )+
  scale_x_discrete(
    limits = c("D1", "Dsn", "Dz", "M1", "Mz", "M3", "M3t", "L2", "W1", "W2", "A1", "A1t", "A2", "A3t", "A4t", "L3"), 
    name = "", guide = guide_axis(angle=90)) +
  scale_y_continuous(
    name = "", 
    limits=c(0, 0.8)) +
  theme_bw() +
  theme(
    text=element_text(family="Arial"),
    legend.position = "none", 
    axis.text.x=element_text(face="bold", size=10), 
    axis.text.y=element_text(face="bold", size=10), 	
    axis.title.x=element_text(face="bold", size=12),
    axis.title.y=element_text(face="bold", size=12)
  )
## to save
tiff('fig 11-plot-lai-ndvi-v8-Rplot.tiff', width = 9, height = 7, units = 'in', res = 300)
#align = "hv" aligns panels both horizontally and vertically
ggarrange(P4, P4a, P3, P3a, ncol = 2, nrow = 2, labels = c("a", "b", "c", "d"), 
          font.label=list(color="black",size=16, face="bold"), align = "hv")
dev.off() ## need this code to finish saving
